package mx.unam.ciencias.modelado.practica2.simulaciones;

/**Enumeracion de los posibles terrenos mediante los cuales se llega al destino. */
public enum Terreno{
    CARRETERA,
    CERRO,
    TERRACERIA,
    URBANO;
}