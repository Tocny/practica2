package mx.unam.ciencias.modelado.practica2;

import mx.unam.ciencias.modelado.practica2.simulaciones.Menu;

/**Clase Main */
public class Main{

    public static Menu menu = new Menu();

    public static void main(String[] args){
        menu.ejecutaMenu();
    }

}